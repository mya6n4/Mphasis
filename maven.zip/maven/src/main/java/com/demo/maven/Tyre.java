package com.demo.maven;

public class Tyre {
	private String brand;
	

	public Tyre(String brand) {
		super();
		this.brand = brand;
	}

	/**
	 * @return the brand
	 */
	public String getBrand() {
		return brand;
	}

	/**
	 * @param brand the brand to set
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}


	@Override
	public String toString() {
		return "Tyre [brand=" + brand + "]";
	}

}
