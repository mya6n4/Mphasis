package com.demo.maven;

import org.springframework.stereotype.Component;

@Component("bike")

public class Bike implements Vehicle {
	public void drive() {
		System.out.println("Bhag rha hai./");
		
	}

}
