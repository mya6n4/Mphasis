package com.demo.maven;

import org.springframework.stereotype.Component;
@Component("car")
public class Car implements Vehicle {
	public void drive() {
		System.out.println("Chal rha hai....");
	}

}
