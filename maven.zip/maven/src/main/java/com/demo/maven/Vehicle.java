package com.demo.maven;


public interface Vehicle {
	void drive();
	

}
